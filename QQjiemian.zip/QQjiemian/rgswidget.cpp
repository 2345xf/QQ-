#include "rgswidget.h"
#include "ui_rgswidget.h"
#include "proto.h"
#include <QCryptographicHash>

rgswidget::rgswidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::rgswidget)
{
    ui->setupUi(this);
    //窗口属性
    this->resize(400,300);
    this->setMaximumSize(400,300);
    this->setMinimumSize(400,300);
    this->setWindowTitle(QString("QQ"));
    this->setWindowIcon(QIcon(QPixmap(QString(":/new/prefix1/QQ .png"))));

    QPalette pal;
    pal.setBrush(QPalette::Background,\
                 QBrush(QPixmap(QString(":/new/prefix1/20.jpg")).scaled(400,300)));
    this->setPalette(pal);

    QFont font;
    font.setPixelSize(14);
    font.setBold(true);

    cntLintEdit = new QLineEdit();
    cntLintEdit->setPlaceholderText(QString("注册账号"));
    cntLintEdit->setFont(font);
    cntLintEdit->setAlignment(Qt::AlignHCenter);//设置对其方式 参数：qt当中的一个宏

    pwdLineEdit = new QLineEdit();
    pwdLineEdit->setPlaceholderText(QString("注册密码"));
    pwdLineEdit->setEchoMode(QLineEdit::Password);//密码输入的时候变成点或者*
    pwdLineEdit->setFont(font);
    pwdLineEdit->setAlignment(Qt::AlignHCenter);//设置对其方式 参数：qt当中的一个宏

    rgsPushBtn = new QPushButton(QString("立即注册"));
    rgsPushBtn->setFont(font);

    //layout
    mainLayout = new QVBoxLayout;
    mainLayout->addWidget(cntLintEdit);
    mainLayout->addWidget(pwdLineEdit);
    mainLayout->addWidget(rgsPushBtn);
    mainLayout->setContentsMargins(70,100,70,100);

    this->setLayout(mainLayout);

    //socket

    sd = new QUdpSocket();
    //连接信号与槽
    connect(rgsPushBtn,SIGNAL(clicked(bool)),this,SLOT(rgsPushBtnslot()));

}


void rgswidget::rgsPushBtnslot()
{//立即注册按钮的槽函数
    //qstring  qbytearr char*
    //获取页面信息
    rgs_t sendbuf;
    QString cntStr = cntLintEdit->text();
    QString pwdStr = pwdLineEdit->text();

    qDebug() << cntStr << pwdStr;

    strncpy(sendbuf.cnt,cntStr.toLatin1().data(),CNISIZE);
//加类名引用静态成员
    QByteArray pwdArr = QCryptographicHash::hash(cntStr.toLatin1(),QCryptographicHash::Sha3_512);
    strncpy(sendbuf.pwd,pwdArr.toHex().data(),PWDSIZE);//tohex 为了数据的一致性 都是16进制
    qDebug() << sendbuf.cnt << sendbuf.pwd;

    sd->writeDatagram((char *)&sendbuf,sizeof(sendbuf),QHostAddress(RGS_SERVER_IP),RGS_SERVER_PORT);

}

rgswidget::~rgswidget()
{
    delete ui;
}

