#include "widget.h"
#include "ui_widget.h"
#include "rgswidget.h"


Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);

    //窗口属性
    this->resize(400,300);
    this->setMaximumSize(400,300);
    this->setMinimumSize(400,300);
    this->setWindowTitle(QString("QQ"));
    this->setWindowIcon(QIcon(QPixmap(QString(":/new/prefix1/QQ .png"))));

    QPalette pal;
    pal.setBrush(QPalette::Background,\
                 QBrush(QPixmap(QString(":/new/prefix1/Snipaste_2022-10-18_23-08-07.jpg")).scaled(400,300)));
    this->setPalette(pal);

    //组件实例化
    //头像
    lable = new QLabel();
    lable->resize(50,50);//设置头像大小
    lable->setPixmap(QPixmap(QString(":/new/prefix1/头像 商务男士.png")).scaled(80,80));//图片适应成lavle的大小
    lableLayout = new QHBoxLayout();//头像所在行的垂直布局
    lableLayout->addStretch();
    lableLayout->addWidget(lable);//添加组件
    lableLayout->addStretch();
    //lableLayout->setContentsMargins(0,0,0,0); //四周没东西

    //用户名 密码
    QFont font;
    font.setPixelSize(14);//设置字体
    font.setBold(true);//加粗

    cntLineEDIT = new QLineEdit();
    cntLineEDIT->setPlaceholderText(QString("QQ号码/手机号/邮箱"));//设置预设的文本
    cntLineEDIT->setFont(font);//设置字体 上面我设置的哪种字体
    pwdLineEdit = new QLineEdit();
    pwdLineEdit->setPlaceholderText(QString("密码"));//设置预设的文本
    pwdLineEdit->setEchoMode(QLineEdit::Password);//输入密码是点或者*
    pwdLineEdit->setFont(font);

    //复选框
    rmbPwdBox = new QCheckBox(QString("记住密码"));
    autoLoginBox = new QCheckBox(QString("自动登录"));
    findPwdBtn = new QPushButton(QString("找回密码"));
    findPwdBtn->setFlat(true);//按钮实现隐藏
    chkboxLayout = new QHBoxLayout();//复选框所在行的垂直布局
    chkboxLayout->addWidget(rmbPwdBox);
    chkboxLayout->addWidget(autoLoginBox);
    chkboxLayout->addWidget(findPwdBtn);
    //登录
    loginBtn = new QPushButton(QString("登录"));
    loginBtn->setFont(font);


    //注册按钮，二维码登录
    rgsBtn = new QPushButton(QString("注册账号"),this);//this 在当前生效
    rgsBtn->setGeometry(10,250,100,30);//x y轴从哪里开始 按钮的宽高占多少
    rgsBtn->setFlat(true);

    imgBtn = new QPushButton(this);
    imgBtn->setFlat(true);
    imgBtn->setGeometry(360,250,30,30);
    imgBtn->setIcon(QIcon(QPixmap(QString(":/new/prefix1/二维码.png"))));
    //imgBtn->setIconSize(); 也可以调整大小


    //布局
    mainLayout = new QVBoxLayout();
    mainLayout->addLayout(lableLayout);
    mainLayout->addWidget(cntLineEDIT);
    mainLayout->addWidget(pwdLineEdit);
    mainLayout->addLayout(chkboxLayout);
    mainLayout->addWidget(loginBtn);
    mainLayout->setContentsMargins(40,30,40,70);//左上右下


    this->setLayout(mainLayout);
    //连接信号与槽
    connect(rgsBtn,SIGNAL(clicked(bool)),this,SLOT(rgsBtnSlot()));
}


void Widget::rgsBtnSlot()
{//点击注册按钮则调用此函数
    rgswidget *reg = new rgswidget;//实例化新页面的对象
    reg->show();
}

Widget::~Widget()
{
    delete ui;
}


