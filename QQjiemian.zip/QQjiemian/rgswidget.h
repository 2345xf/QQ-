#ifndef RGSWIDGET_H
#define RGSWIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QUdpSocket>
namespace Ui {
class rgswidget;
}

class rgswidget : public QWidget
{
    Q_OBJECT

public:
    explicit rgswidget(QWidget *parent = 0);
    ~rgswidget();
private slots:
    void rgsPushBtnslot();

private:
    Ui::rgswidget *ui;
    QLineEdit *cntLintEdit;
    QLineEdit *pwdLineEdit;
    QPushButton *rgsPushBtn;
    QVBoxLayout *mainLayout;

    QUdpSocket *sd;


};

#endif // RGSWIDGET_H
