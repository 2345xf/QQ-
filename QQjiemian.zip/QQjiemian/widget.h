#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QVBoxLayout>
#include <QHBoxLayout>


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();
    //声明槽函数
private slots:
        void rgsBtnSlot();

private:
    Ui::Widget *ui;

    QLabel *lable;                  //头像
    QLineEdit *cntLineEDIT;         //用户名
    QLineEdit *pwdLineEdit;         //密码
    QCheckBox *autoLoginBox;        //自动登录
    QCheckBox *rmbPwdBox;           //记住密码
    QPushButton *findPwdBtn;        //找回密码
    QPushButton *loginBtn;          //登录按钮
    QPushButton *rgsBtn;            //注册按钮
    QPushButton *imgBtn;            //二维码登录

    QHBoxLayout *lableLayout;       //头像所在行的垂直布局
    QHBoxLayout *chkboxLayout;      //复选框所在行的垂直布局
    QVBoxLayout *mainLayout;



};

#endif // WIDGET_H
