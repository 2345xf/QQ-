#ifndef PROTO_H
#define PROTO_H

//客户端与服务器短的注册功能协议
#define RGS_SERVER_IP           "192.168.222.1"
#define RGS_SERVER_PORT         1100

#define CNISIZE     20
#define PWDSIZE     256

enum
{
    RGS_OK,
    RGS_EXISTSL,
    RGS_ERROR
};

typedef struct
{
    char cnt [CNISIZE];
    char pwd [PWDSIZE];
    int8_t rgs_state;
}rgs_t;
















#endif // PROTO_H
